# Soshimee Addons
A [ChatTriggers](https://chattriggers.com/) module. Focused on Hypixel SkyBlock Dungeons (especially F7/M7).

"Made in Korea"

Questions that were never asked but will be answered:
- Why did you upload this so late? Couldn't be bothered
- Why does this question exist? Looks less awkward to have 2 or more questions

# Features:

 - Custom 0 ping terminal GUI <br>
 - i4 Helper <br>
 - Tick Timers <br>
 - Blood Helper <br>
 - Party Commands <br>
 - Auto Kick <br>
 - SBE Blood Fix <br>
 and more!


# How to use:

Download [ChatTriggers](https://chattriggers.com/) for 1.8.9.

Download the latest version from this repository's [releases link](https://github.com/soshimee-dev/soshimeeaddons/releases) or [module download](https://github.com/soshimee-dev/soshimeeaddons/releases/download/RELEASE/soshimeeaddons-2.8.6.zip).

Download and unzip (extract) the .zip file (soshimeeaddons-2.8.6.zip) into the ChatTriggers modules folder as you would for any other module.

Reload your modules in game (/ct reload) and then type /sa in chat.

Enjoy!

<br>
<br>

Disclaimer:
 - Soshimee addons is not a cheat module as it does not modify packets in anyway
